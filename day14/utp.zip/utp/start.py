import unittest
from BeautifulReport import BeautifulReport as bf
from conf.setting import CASE_PATH
from core.tools import make_today_dir
import datetime
def run_case():
    suite = unittest.TestSuite() #建测试集合
    cases = unittest.defaultTestLoader.discover(CASE_PATH,'*.py')
    #去某个目录下找测试用例
    for case in cases:
        suite.addTest(case)  #循环把每个文件里面的case加入到测试集合里面
    report = bf(suite) #运行测试用例

    path = make_today_dir() #创建今天的文件夹，存放报告
    file_name = 'report_%s.html'%datetime.datetime.now().strftime('%H%M%S')#生成新的文件名
    report.report(filename=file_name,description='接口测试',log_path=path)#生成报告
    print(report.success_count)
    print(report.failure_count)

#产生报告
run_case()