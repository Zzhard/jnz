import flask

server = flask.Flask(__name__) #把当前这个python文件当做一个服务
#这个就指提供服务