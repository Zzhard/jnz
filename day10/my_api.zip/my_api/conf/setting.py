
mysql_info = {
    'host':'118.24.3.40',
    'port':3306,
    'user':'jxz',
    'password':'123456',
    'db':'jxz',
    'charset':'utf8',
    'autocommit':True
}
#mysql 配置信息


server_info = {
    "host":'0.0.0.0',
    "port":5000, #启动服务的端口号
    'debug':True #是否是调试模式
}
